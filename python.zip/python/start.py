#!/usr/bin/env python
# encoding=utf-8 
#
# Last updat
# google search results crawler 

import sys
import os
import requests
reload(sys)
sys.setdefaultencoding('utf-8')
import urllib
import urllib2, socket, time
import gzip, StringIO
import re, random, types
import string
import Queue
import threading
import signal
from bs4 import BeautifulSoup

urls = []
urls1 = []
base_url = 'https://www.google.com/'
results_per_page = 100
user_agents = list()

Ips = []  # 保存解析出的IP
Max_threads = 250  # 最大现程的个数
resolved_cnt = 0  # 解析出的有效IP的个数


# results from the search engine
# basically include url, title,content
class SearchResult:
    def __init__(self):
        self.url = ''
        self.title = ''
        self.content = ''

    def getURL(self):
        return self.url

    def setURL(self, url):
        self.url = url

    def getTitle(self):
        return self.title

    def setTitle(self, title):
        self.title = title

    def getContent(self):
        return self.content

    def setContent(self, content):
        self.content = content

    def printIt(self, prefix=''):
        print 'url\t->', self.url
        print 'title\t->', self.title
        print 'content\t->', self.content
        print

    def writeFile(self, filename):
        file = open(filename, 'a')
        try:
            file.write('url:' + self.url + '\n')
            file.write('title:' + self.title + '\n')
            file.write('content:' + self.content + '\n\n')

        except IOError, e:
            print 'file error:', e
        finally:
            file.close()


class GoogleAPI:
    def __init__(self):
        timeout = 40
        socket.setdefaulttimeout(timeout)

    def randomSleep(self):
        sleeptime = random.randint(60, 120)
        time.sleep(sleeptime)

    # extract the domain of a url
    def extractDomain(self, url):
        domain = ''
        pattern = re.compile(r'http[s]?://([^/]+)/', re.U | re.M)
        url_match = pattern.search(url)
        if (url_match and url_match.lastindex > 0):
            domain = url_match.group(1)

        return domain

    # extract a url from a link
    def extractUrl(self, href):
        url = ''
        pattern = re.compile(r'(http[s]?://[^&]+)&', re.U | re.M)
        url_match = pattern.search(href)
        if (url_match and url_match.lastindex > 0):
            url = url_match.group(1)

        return url

        # search web

    # @param query -> query key words
    # @param lang -> language of search results  
    # @param num -> number of search results to return 
    def search(self, query, lang='en', num=results_per_page):
        search_results = list()
        query = urllib2.quote(query)
        p=0
        target = open("url_r", 'w')
        if p < 10000:
            start = p
            url = '%s/search?hl=%s&num=%d&start=%s&q=%s' % (base_url, lang, results_per_page, start, query)
            print url
            retry = 3
            while (retry > 0):
                try:
                    request = urllib2.Request(url)
                    length = len(user_agents)
                    index = random.randint(0, length - 1)
                    user_agent = user_agents[index]
                    request.add_header('User-agent', user_agent)
                    request.add_header('connection', 'keep-alive')
                    request.add_header('Accept-Encoding', 'gzip')
                    request.add_header('referer', base_url)
                    response = urllib2.urlopen(request)
                    html = response.read()
                    if (response.headers.get('content-encoding', None) == 'gzip'):
                        html = gzip.GzipFile(fileobj=StringIO.StringIO(html)).read()
                    # print html
                    soup = BeautifulSoup(html, "html.parser")
                    
                    for title in soup.select('cite'):
                        target.write(title.get_text() + '\n')
                    break;
                except urllib2.URLError, e:
                    print 'url error:', e
                    self.randomSleep()
                    retry = retry - 1
                    continue

                except Exception, e:
                    print 'error:', e
                    retry = retry - 1
                    self.randomSleep()
                    continue
            P+=100
        target.close()


def load_user_agent():
    fp = open('./url_search/user_agents', 'r')

    line = fp.readline().strip('\n')
    while (line):
        user_agents.append(line)
        line = fp.readline().strip('\n')
    fp.close()


def Arrangement():
    fp = open("url_r", 'r')
    fw = open("url1", 'w')
    url_x = fp.readline()
    while (url_x):
        if url_x.startswith('https'):
            fw.write("https://" + url_x.split('/')[2] + '\n')
        else:
            fw.write("http://" + url_x.split('/')[0] + '\n')
        url_x = fp.readline().strip('\n')
    fp.close()
    fw.close()
    outfile = open('.\\url', 'w')  # 新的文
    list_1 = []
    for line in open('url1'):
        tmp = line.strip()
        if tmp not in list_1:
            list_1.append(tmp)
            outfile.write(line)
    outfile.close()
    os.remove("url1")
    os.remove("url_r")


def url_resolver(url_file):
    fread_url = open(url_file, 'r')
    fwrite_domain = open('domain', 'w')
    url = fread_url.readline().strip('\n')
    while url:
        urls1.append(url)
        url = fread_url.readline().strip('\n')
    for url in urls1:
        proto, rest = urllib.splittype(url)
        res, rest = urllib.splithost(rest)
        if not res:
            print("unknow")
        else:
            print(res)
            fwrite_domain.write(str(res) + '\n')
    fread_url.close()
    fwrite_domain.close()


def init_urls(url_file):
    fr = open(url_file, 'r')
    url = fr.readline().strip('\n')
    while url:
        urls.append(url)
        url = fr.readline().strip('\n')
    fr.close()


def host_to_ip(host):
    global resolved_cnt
    try:
        family, socktype, proto, canonname, sockaddr = socket.getaddrinfo(
            host, 0, socket.AF_UNSPEC, socket.SOCK_STREAM)[0]

        if family == socket.AF_INET:
            ip, port = sockaddr
        elif family == socket.AF_INET6:
            ip, port, flow_info, scope_id = sockaddr
    # resolved_cnt+=1
    except Exception:
        ip = None
    print ip
    return ip


def write_ips(resolved_ips):
    fwrite = open(resolved_ips, 'a')
    i=0
    for ip in Ips:
        fwrite.write(urls[i] + " " + str(ip) + '\n')
        i+=1
    fwrite.close()


class processWork(threading.Thread):
    def __init__(self, queue):
        threading.Thread.__init__(self)
        self.queue = queue

    def run(self):
        if mutex.acquire(1):
            while True:
                if self.queue.empty(): break  # 如果队列为空 ，break跳出循环
                host = self.queue.get()
                temp = host_to_ip(host)
                if temp:  # 如果 IP为空 则不添加到IPs列表中
                    Ips.append(temp)
                self.queue.task_done()
            mutex.release()


def cars():
    start = time.time()
    url_file = "domain"
    resolved_ips = "IPS"
    thread_max_count = 300
    if thread_max_count > Max_threads or thread_max_count < 1:
        thread_max_count = Max_threads
    init_urls(url_file)
    queue = Queue.Queue()
    for url in urls:
        queue.put(url)
    for x in range(thread_max_count):
        worker = processWork(queue)
        worker.deamon = True
        worker.start()
    queue.join()
    write_ips(resolved_ips)
    print "total hosts: %d,resolved host:%d, spend %0.3f s" % (len(urls), len(Ips), time.time() - start),

def url():
    fp = open('IPS', 'r')
    fp1 = open("jinweidu.txt", 'w')
    line = fp.readline().strip('\n')
    i = 1
    while (line):
        line = line.split(' ')[1]
        url = "http://ipaddress.is/" + line + "#.WhADQ7RdJBR"
        response = requests.get(url, headers=load_user_agent()).content
        soup = BeautifulSoup(str(response), 'html.parser')
        # ws.title = self.IP_addr + ' address'
        content = soup.find_all('table', {'class': 'table table-bordered'})[0]
        info = []
        info.append(line)
        info.append(re.findall(re.compile(r'Latitude</td><td>(.*?)</td></tr>'), str(content))[0])
        info.append(re.findall(re.compile(r'Longitude</td><td>(.*?)</td></tr>'), str(content))[0])
        fp1.write(line.split(' ')[0] +" " + info[0] + " " + info[1] + " " + info[2]+'\n')
        print i
        i += 1
        line = fp.readline().strip('\n')
    fp1.close()
    fp.close()


def crawler():
    print "---------Load use agent string from file..--------"
    load_user_agent()

    print"----------Start Create a GoogleAPI instance..------"
    api = GoogleAPI()

    # set expect search results to be crawled
    expect_num = 10
    # if no parameters, read query keywords from file
    if (len(sys.argv) < 2):
        keywords = open('./url_search/keywords', 'r')
        keyword = keywords.readline()
        while (keyword):
            api.search(keyword, num=expect_num)
            keyword = keywords.readline()
        keywords.close()
    else:
        keyword = sys.argv[1]
        results = api.search(keyword, num=expect_num)

    Arrangement()
    print "-----------start   URL_Arrangement  -------------"
    url_resolver("url")
    print "-----------start   URL-->IP  -------------------"
    cars()

    print "\n-----------start   IP-->LO_and_LA  -------------"
    url()



if __name__ == '__main__':
    #
    mutex = threading.Lock()
    crawler()
